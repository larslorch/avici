train_gp <-
function(X,y,pars = list())
{
    stop('GP regression not implemented.')
    return(NULL)
}
